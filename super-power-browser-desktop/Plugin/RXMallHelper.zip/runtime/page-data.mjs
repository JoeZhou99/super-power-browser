const object=value=>value&&typeof value==='object'&&!Array.isArray(value)?value:{};
function fields(value,keys){
  const result={};
  for(const key of keys){
    const item=object(value)[key];
    if(['string','number','boolean'].includes(typeof item)||item===null)result[key]=item;
  }
  return result;
}

// PAC/auth/socket configuration stays in the worker. Content pages and content
// scripts only receive these public display and behavior options.
export function publicPageInitData(value){
  const result=fields(value,['desktopProtocol','browserId','sysMallId','appVersion','browserVersion','language','language_setPlugin','translation_ip','ip_scene','isdebug']);
  result.commonParams=fields(value?.commonParams,['chromiumVersion','is_plugin_sync_cookie']);
  result.logoInfo=fields(value?.logoInfo,['brand_name','main_logo']);
  result.localGeo=fields(value?.localGeo,['ip','country_code','country_name','region_name','city_name']);
  result.privateMode=fields(value?.privateMode,['autoOpenMallHome','isPrivateMode']);
  return result;
}

// Existing account fields are required by the account-helper handoff. Proxy
// authentication and candidate connection objects are separate and omitted.
export function publicShopDetails(value){
  const result=fields(value,['id','mall_id','mall_name','platformName','site_info_id','mall_account','password_key','password_k','random_string','mall_account_lock','mall_address','check_env','jump_method','sync_cookie','lasting','cookie_key','is_check_agent','ip_scene','is_report','online_count','ip_local_region','uid','sms_remind']);
  if(Array.isArray(value?.jump_urls))result.jump_urls=value.jump_urls.filter(item=>typeof item==='string');
  if(Array.isArray(value?.ip_white_list))result.ip_white_list=value.ip_white_list.filter(item=>typeof item==='string');
  result.front_addendum_info=fields(value?.front_addendum_info,['autoInjectPasskey','disabledPasskey']);
  result.has_one_platform=fields(value?.has_one_platform,['name','link','platform_id','logo']);
  for(const key of ['white_list','black_list'])result.has_one_platform[key]=Array.isArray(value?.has_one_platform?.[key])?value.has_one_platform[key].filter(item=>typeof item==='string'):[];
  result.has_one_user_agent=fields(value?.has_one_user_agent,['ua']);
  result.has_one_mac_user_agent=fields(value?.has_one_mac_user_agent,['ua']);
  // The user's residential proxy IP is an existing public device display field.
  result.has_one_agent_ip=fields(value?.has_one_agent_ip,['id','ip','map_ip','ip_type','web_type','area_name','equipment_name','equipment_code','type_name']);
  result.has_one_agent_ip_v2={};
  return result;
}
