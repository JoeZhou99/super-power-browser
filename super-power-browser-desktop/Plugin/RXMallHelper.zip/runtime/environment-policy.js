// Configured by the desktop before launch.
