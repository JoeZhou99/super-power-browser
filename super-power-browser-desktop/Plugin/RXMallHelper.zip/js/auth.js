const _ = {
  VUE_APP_BASE_NEW_API: "http://127.0.0.1:18080/extension",
  VUE_APP_APM: "http://127.0.0.1:18080/extension/services/apm",
  VUE_APP_ADMIN: "http://127.0.0.1:18080/extension/services/admin",
  VUE_APP_ADMIN_OPEN: "http://127.0.0.1:18080/extension/services/admin-open",
  VUE_APP_WSS: "ws://127.0.0.1:18080/extension/services/wss",
  VUE_APP_MMS: "http://127.0.0.1:18080",
  VUE_APP_MMS_NEW: "http://127.0.0.1:18080/extension/services/mms-new",
  VUE_APP_GW_OPEN: "http://127.0.0.1:18080/extension/services/gw-open",
  VUE_APP_EVAL: "http://127.0.0.1:18080/extension/services/eval",
  VUE_APP_OPEN: "http://127.0.0.1:18080/extension/services/open",
};
let r = {};
r = _;
const s = r,
  a = s.VUE_APP_MMS,
  c = (e) =>
    new Promise((n) => {
      chrome.cookies.set(
        {
          url: e.url || a,
          name: e.name,
          value: e.value || "",
          expirationDate: e.expirationDays ? Date.now() / 1e3 + e.expirationDays * 86400 : void 0,
          domain: e.domain,
          path: e.path || "/",
          secure: e.secure ?? false,
          httpOnly: e.httpOnly ?? !1,
          sameSite: e.sameSite || "lax",
        },
        (o) => {
          n(!!o);
        },
      );
    }),
  h = (e) =>
    new Promise((n) => {
      chrome.cookies.get({ url: e.url || a, name: e.name }, (o) => {
        n(o?.value || null);
      });
    }),
  m = "get_chrome_cookie",
  l = s.VUE_APP_MMS;
function P(e) {
  const n = e.url ?? l,
    { name: o } = e;
  return typeof chrome > "u" || !chrome.runtime?.sendMessage
    ? Promise.resolve(null)
    : chrome.runtime
        .sendMessage({ type: m, url: n, name: o })
        .then((i) => i?.value ?? null)
        .catch(() => null);
}
const u = "chrome_token";
function f() {
  return typeof chrome < "u" && typeof chrome.cookies?.get == "function";
}
async function t(e) {
  return f() ? h(e) : P(e);
}
const w = "browserVersion";
async function E() {
  return await t({ name: w });
}
async function g() {
  return await t({ name: u });
}
async function A(e) {
  return await c({ name: u, value: e });
}
async function y() {
  return await t({ name: "lang" });
}
async function V(e) {
  return await c({ name: "lang", value: e });
}
export { m as G, g as a, V as b, E as c, y as g, A as s };
